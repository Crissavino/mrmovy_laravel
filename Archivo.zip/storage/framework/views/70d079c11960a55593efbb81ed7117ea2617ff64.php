<?php $__env->startSection('title', 'Información de la película'); ?>

<?php $__env->startSection('container'); ?>

<section class="contenedor mas-info">

	<div class="sidebar">
	    <div class="portada-sidebar">
	        <img src="<?php echo e(asset($movie->cover)); ?>" alt="" class="portada-pelicula">
	    </div>

	    <div class="botones-sidebar">
			<a href="/resultados">
				<div class="boton">
					Volver a los resultados
				</div>
			</a>

            <?php if(auth()->user()->is_admin): ?>
            	<a href="/carga/edicion/<?php echo e($movie->id); ?>">
			        <div class="boton-verde">
			          Editar esta pelicula
			        </div>
		        </a>
	        <?php endif; ?>

	        <?php if(auth()->user()->is_admin): ?>
		        <form action="/delete/<?php echo e($movie->id); ?>" method="post">
		        	<?php echo csrf_field(); ?>
		        	<button type="submit" class="boton-rojo" style="width: 100%;">Eliminar esta pelicula</button>
		        </form>
	        <?php endif; ?>

	        <?php if( $movie->netflix || $movie->trailer): ?>
	        	<div class="botones-extras">
			    	<?php if($movie->netflix): ?>
						<a href="<?php echo e($movie->netflix); ?>">
							<div class="boton-gris">
								<img src="/images/logo-netflix.png" alt="Icono para ver <?php echo e($movie->name); ?> en netflix">
							</div>
						</a>
			    	<?php endif; ?>

			    	<?php if($movie->trailer): ?>
						<a href="<?php echo e($movie->trailer); ?>">
							<div class="boton-gris trailer">
								<img src="/images/ver-trailer.png" alt="">Trailer
							</div>
						</a>
			    	<?php endif; ?>

	        	</div>
	        <?php endif; ?>

	        
	    </div>
	</div>

	<div class="info-pelicula">

		<h1><?php echo e($movie->title); ?></h1>

		<div class="boton-info text-azul">
			<?php $__currentLoopData = $movie->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	   			<?php echo e($genre->name); ?>

	   		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="boton-info">
			<?php echo e($movie->year); ?>

		</div>
		<div class="boton-info">
			<?php echo e($movie->length); ?> minutos
		</div>

	<div class="resumen-pelicula">
		<p>
			<?php echo e($movie->resume); ?>

		</p>
	</div>

	<h2>Actores</h2>
	<?php $__currentLoopData = $movie->actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="boton-info">
			<?php echo e($actor->name); ?>

		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<h2>Producción</h2>
	<?php $__currentLoopData = $movie->producers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="boton-info">
			<?php echo e($producer->name); ?>

		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
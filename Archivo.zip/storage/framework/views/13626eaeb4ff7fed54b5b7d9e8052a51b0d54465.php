<?php if(auth()->user()->is_admin == 0): ?>
	<script>window.location = "/resultados";</script>
<?php endif; ?>



<?php $__env->startSection('title', 'Carga de Productores'); ?>

<?php $__env->startSection('container'); ?>
	<section class="contenedor">
		<h1 class="titulo-carga">Cargar un productor</h1>
		<form action="" class="formulario-carga" method="POST">
			<?php echo csrf_field(); ?>
			<label for="actor">Nombre del productor</label>
			<br>
			<input type="" name="name" id="actor">
			<br>
			<button type="submit" class="boton">Cargar productor</button>
		</form>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(auth()->user()->survey == false): ?>
	<script>window.location = "/paso1";</script>
<?php endif; ?>



<?php $__env->startSection('title', 'Tus resultados / Mr. Movy'); ?>

<?php $__env->startSection('container'); ?>

	<section class="contenedor">

		<h2 class="titulo-resultados"><span>¡Felicitaciones!</span> Estas son nuestras recomendaciones según tus gustos, prometemos no defraudarte :)</h2>

		<?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<article class="tarjeta-resultados resultado<?php echo e($key); ?>">
				<img src="<?php echo e(asset($pelicula->cover)); ?>" class="tarjeta-pelicula" alt="">
				<div class="pelicula">
				    <h2><?php echo e($pelicula->title); ?></h2>
				    <p class="fecha"><?php echo e($pelicula->year); ?></p>
				   	
				    <p class="generos">
				    	<?php $__currentLoopData = $pelicula->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				   			<?php echo e($genre->name); ?>

				   		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    </p>
				    <p class="actores">
				    	<?php $__currentLoopData = $pelicula->actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				   			<?php echo e($actor->name); ?>

				   		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    </p>
				    <p class="director">Dirigida por <strong>
				    	<?php $__currentLoopData = $pelicula->producers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				   			<?php echo e($producer->name); ?>

				   		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    </strong></p>
				    <div class="botones">
				        <a href="/info/<?php echo e($pelicula->id); ?>">
				        	<div class="boton-gris">Más info</div>
				    	</a>
				    	<?php if($pelicula->netflix): ?>
							<a href="<?php echo e($pelicula->netflix); ?>" target="_blank">
								<div class="boton-gris boton-netflix">
									<img src="images/logo-netflix.png" alt="">
								</div>
							</a>
				    	<?php endif; ?>
				        
				        <?php if($pelicula->trailer): ?>
							<a href="<?php echo e($pelicula->trailer); ?>" target="_blank">
						        <div class="boton-gris trailer">
						         	<img src="images/ver-trailer.png" alt="">Trailer
						        </div>
				        	</a>
				    	<?php endif; ?>
				        
				        <button name="<?php echo e($pelicula->id); ?>" onclick="ck(this)"class="lavi boton lv lvi<?php echo e($key); ?>" value="<?php echo e($key); ?>">
				          La ví
				        </button>
				    </div>
				</div>
			</article>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</section>

	<script type="text/javascript">

		function actualizarView (movieId) {
			var campos = {
				movieId: movieId,
			}

			var datosDelFormulario = new FormData();
			datosDelFormulario.append('datos', JSON.stringify(campos))

			fetch("/insertar", { 
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
				method: 'POST',
				body: datosDelFormulario,
			}
			)
			.then(function (response) {
				return response.text();
			})
			.then(function (data) {
				console.log(data)
			})

		}

		var largo = <?php echo count($peliculas); ?>;

		for (var i = 3; i < largo; i++) {
			document.querySelector('.resultado' + i).style.display = "none"
		}

		var clickT = 4
		
		var botonLV = document.querySelectorAll('.lv')

		function ck (elemento) {
			var tarjeta = document.querySelector('.resultado' + elemento.value)
			tarjeta.style.display = 'none'

			actualizarView(elemento.name)

			document.querySelector('.resultado' + clickT).style.display = "block"
			clickT ++
		}

	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
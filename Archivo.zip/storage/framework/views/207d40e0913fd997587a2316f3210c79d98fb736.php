<?php if(auth()->user()->is_admin == 0): ?>
	<script>window.location = "/resultados";</script>
<?php endif; ?>



<?php $__env->startSection('title', 'Carga de Actores'); ?>

<?php $__env->startSection('container'); ?>
	<section class="contenedor">
		<h1 class="titulo-carga">Cargar un actor</h1>
		<form action="" class="formulario-carga" method="POST">
			<?php echo csrf_field(); ?>
			<label for="actor">Nombre de actor</label>
			<br>
			<input type="" name="name" id="actor">
			<br>
			<button type="submit" class="boton">Cargar actor</button>
		</form>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
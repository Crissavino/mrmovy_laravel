<ul style="display: none;">
	<?php $__currentLoopData = $userGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userGenre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="userGenres"><?php echo e($userGenre->id); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<ul style="display: none;">
	<?php $__currentLoopData = $userTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userTag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="userTag"><?php echo e($userTag->id); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>



<?php $__env->startSection('title', 'Paso 3 de 3'); ?>

<?php $__env->startSection('container'); ?>

	<section class="contenedor">
		<section class="generos">

			<h2><span>Paso 1 de 3:</span> elije tus géneros preferidos</h2>
			<p>Elije tus géneros de preferencia, <b>solo puedes elegir hasta 3 géneros.</b></p>

			<section class="tarjetas">

				<?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="tarjeta" id="tarjeta<?php echo e($key); ?>" style="display: none;">
						<div class="c1">
							<img src="">
						</div>

						<ul style="display: none;">
							<?php $__currentLoopData = $pelicula->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyTag => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="genero<?php echo e($key); ?>"><?php echo e($tag->id); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>

						<ul style="display: none;">
							<?php $__currentLoopData = $pelicula->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyGenre => $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="tag<?php echo e($key); ?>"><?php echo e($genre->id); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>

						<div class="c2">
							<span>1 de 10</span>
							<h3><?php echo e($pelicula->title); ?> <span><?php echo e($pelicula->year); ?></span></h3>

							<div class="botones">
								<div class="boton-interno" id="la-vi-mg<?php echo e($key); ?>">
									<img src="">
									La ví y me gustó <?php echo e($key); ?>

								</div>

								<div class="boton-interno" id="la-vi-mi<?php echo e($key); ?>">
									<img src="">
									La ví y me da igual
								</div>

								<div class="boton-interno" id="la-vi-nmg<?php echo e($key); ?>">
									<img src="">
									La ví y no me gustó
								</div>

								<div class="boton-interno" id="no-vi<?php echo e($key); ?>">
									<img src="">
									No la vi
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				

			

			</section>

			
		</section>
	</section>

	<script type="text/javascript">

		userId = <?php echo e(auth()->user()->id); ?>;
		var userGenres = document.querySelectorAll('.userGenres')
		var userTags = document.querySelectorAll('.userTag')


		function actualizar (userId,genreId,score) {
			var campos = {
				userId: userId,
				genreId: genreId,
				score: score
			}

			var datosDelFormulario = new FormData();
			datosDelFormulario.append('datos', JSON.stringify(campos))

			fetch("/paso3", { 
				headers: {
    			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				method: 'POST',
				body: datosDelFormulario,
				}
			)
			.then(function (response) {
				return response.text();
			})
			.then(function (data) {
				console.log(data)
				console.log('aca redirigimos')

			})

		}

		function actualizarTag (userId,tagId,score) {
			var campos = {
				userId: userId,
				tagId: tagId,
				score: score
			}

			var datosDelFormulario = new FormData();
			datosDelFormulario.append('datos', JSON.stringify(campos))

			fetch("/paso3Tag", { 
				headers: {
    			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				method: 'POST',
				body: datosDelFormulario,
				}
			)
			.then(function (response) {
				return response.text();
			})
			.then(function (data) {
				console.log(data)
				console.log('aca redirigimos')

			})

		}

		function actualizarTarjeta (puntaje) {

			var generoUno = document.querySelectorAll('.genero' + click)
			var tags = document.querySelectorAll('.tag' + click)

			generoUno.forEach( function(element, index) {
				userGenres.forEach( function(userGenre) {
					if (userGenre.innerText == element.innerText) {
						actualizar(userId, userGenre.innerText, puntaje)
					}
				});
			});

			tags.forEach( function(element, index) {
				userTags.forEach( function(userTag) {
					if (userTag.innerText == element.innerText) {
						actualizarTag(userId, userTag.innerText, puntaje)
					}
				});
			});

			tarjetaActual.style.display = "none"
			proximaTarjeta.style.display = ""

			click++
			nextClick++

			tarjetaActual = document.querySelector('#tarjeta' + click)
			proximaTarjeta = document.querySelector('#tarjeta' + nextClick)

			console.log(tarjetaActual)
			console.log(proximaTarjeta)

		}

		var click = 0
		var nextClick = 1

		var generoUno = document.querySelectorAll('.genero' + click)

		var tarjetaActual = document.querySelector('#tarjeta' + click)
		var proximaTarjeta = document.querySelector('#tarjeta' + nextClick)

		var botonLaViMeGustoUno = document.querySelector('#la-vi-mg0')
		var botonLaViMeGustoDos = document.querySelector('#la-vi-mg1')
		var botonLaViMeGustoTres = document.querySelector('#la-vi-mg2')
		var botonLaViMeGustoCuatro = document.querySelector('#la-vi-mg3')
		var botonLaViMeGustoCinco = document.querySelector('#la-vi-mg4')
		var botonLaViMeGustoSeis = document.querySelector('#la-vi-mg5')
		var botonLaViMeGustoSiete = document.querySelector('#la-vi-mg6')
		var botonLaViMeGustoOcho = document.querySelector('#la-vi-mg7')
		var botonLaViMeGustoNueve = document.querySelector('#la-vi-mg8')
		var botonLaViMeGustoDiez = document.querySelector('#la-vi-mg9')

		botonLaViMeGustoUno.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoDos.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoTres.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoCuatro.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoCinco.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoSeis.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoSiete.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoOcho.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoNueve.addEventListener('click', function(){ actualizarTarjeta(2) })
		botonLaViMeGustoDiez.addEventListener('click', function(){ actualizarTarjeta(2) })

		tarjetaActual.style.display = ""

	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
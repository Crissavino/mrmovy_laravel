<?php if(auth()->user()->survey == true): ?>
	<script>window.location = "/resultados";</script>
<?php endif; ?>

<ul style="display: none;">
	<?php $__currentLoopData = $userGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userGenre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="userGenres"><?php echo e($userGenre->id); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<ul style="display: none;">
	<?php $__currentLoopData = $userTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userTag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="userTag"><?php echo e($userTag->id); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>



<?php $__env->startSection('title', 'Paso 3 de 3'); ?>

<?php $__env->startSection('container'); ?>

	<section class="contenedor">
		<section class="generos">

			<h2><span>Paso 3 de 3:</span> Cuéntanos un poco de lo que ya viste</h2>

			<section class="tarjetas">

				<?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<p id="id<?php echo e($key); ?>" style="display: none;"><?php echo e($pelicula->id); ?></p>
					<div class="tarjeta" id="tarjeta<?php echo e($key); ?>" style="display: none;">
						<div class="c1">
							<img src="<?php echo e(asset($pelicula->cover)); ?>">
						</div>

						<ul style="display: none;">
							<?php $__currentLoopData = $pelicula->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyTag => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="genero<?php echo e($key); ?>"><?php echo e($tag->id); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>

						<ul style="display: none;">
							<?php $__currentLoopData = $pelicula->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyGenre => $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="tag<?php echo e($key); ?>"><?php echo e($genre->id); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>

						<div class="c2">
							<span><?php echo e($key+1); ?>  de 10</span>
							<h3><?php echo e($pelicula->title); ?> <span><?php echo e($pelicula->year); ?></span></h3>

							<div class="botones">
								<div class="boton-interno" id="la-vi-mg<?php echo e($key); ?>">
									<img src="/images/megusto.png">
									La ví y me gustó
								</div>

								<div class="boton-interno" id="la-vi-mdi<?php echo e($key); ?>">
									<img src="/images/medaigual.png">
									La ví y me da igual
								</div>

								<div class="boton-interno" id="la-vi-nmg<?php echo e($key); ?>">
									<img src="/images/nomegusto.png">
									La ví y no me gustó
								</div>

								<div class="boton-interno" id="no-vi<?php echo e($key); ?>">
									<img src="/images/nolavi.png">
									No la vi
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			

			</section>
		</section>
	</section>

	<script type="text/javascript" src=/js/pasos.js></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
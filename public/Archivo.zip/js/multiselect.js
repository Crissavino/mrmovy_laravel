$('#keep-order').multiSelect({ keepOrder: true });
$('#keep-order2').multiSelect({ keepOrder: true });